# Lost & Found Community - Frontend

A modern, responsive React application for a lost and found community platform.

## Features

### 🏠 **Home Page**
- Hero section with search functionality
- Community statistics display
- Recent lost and found items grid
- Category and type filtering
- Responsive design with animations

### 🔍 **Search & Discovery**
- Advanced search with filters
- Category-based filtering
- Item type filtering (Lost/Found)
- Sort by date, views, likes
- Grid and list view modes
- Real-time search results

### 📍 **Map View**
- Interactive map with Leaflet integration
- Custom markers for lost/found items
- Location-based item discovery
- User location detection
- Map and list view toggle

### 📝 **Post Items**
- Comprehensive item posting form
- Image upload with drag & drop
- Location selection with geolocation
- Category and type selection
- Contact information management
- Form validation and error handling

### 👤 **User Profile**
- Profile management with avatar upload
- Personal statistics dashboard
- User's posted items display
- Profile editing capabilities
- Achievement tracking

### 💬 **Messaging System**
- Real-time chat functionality
- Conversation management
- Message history
- Item context in conversations
- Unread message indicators

### 🏆 **Leaderboard**
- Community rankings
- Multiple ranking categories
- Time-based filtering
- User statistics display
- Achievement recognition

### 🔐 **Authentication**
- User registration and login
- Protected routes
- Session management
- Password validation
- Form validation

## Technology Stack

- **React 18** - Modern React with hooks
- **React Router 6** - Client-side routing
- **Tailwind CSS** - Utility-first CSS framework
- **Framer Motion** - Animation library
- **React Query** - Data fetching and caching
- **React Hook Form** - Form management
- **React Dropzone** - File upload handling
- **Leaflet** - Interactive maps
- **React Hot Toast** - Notifications
- **Heroicons** - Icon library
- **Date-fns** - Date manipulation
- **Axios** - HTTP client

## Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── auth/           # Authentication components
│   ├── items/          # Item-related components
│   ├── layout/         # Layout components
│   └── ui/             # Generic UI components
├── contexts/           # React contexts
│   ├── AuthContext.js  # Authentication state
│   ├── ChatContext.js  # Chat functionality
│   └── SocketContext.js # WebSocket connection
├── pages/              # Page components
│   ├── Home.js         # Landing page
│   ├── Login.js        # Login page
│   ├── Register.js     # Registration page
│   ├── Profile.js      # User profile
│   ├── PostItem.js     # Item posting
│   ├── ItemDetail.js   # Item details
│   ├── SearchResults.js # Search page
│   ├── MapView.js      # Map interface
│   ├── Chat.js         # Chat list
│   ├── ChatDetail.js   # Chat interface
│   ├── Leaderboard.js  # Community rankings
│   └── NotFound.js     # 404 page
├── App.js              # Main app component
├── index.js            # App entry point
└── index.css           # Global styles
```

## Key Features

### 🎨 **Modern UI/UX**
- Clean, intuitive design
- Responsive across all devices
- Smooth animations and transitions
- Consistent color scheme and typography
- Accessible design patterns

### ⚡ **Performance**
- Optimized bundle size
- Lazy loading for routes
- Image optimization
- Efficient state management
- Caching strategies

### 🔒 **Security**
- Protected routes
- Input validation
- XSS protection
- Secure authentication flow
- Error boundary handling

### 📱 **Mobile-First**
- Responsive design
- Touch-friendly interactions
- Mobile-optimized forms
- Progressive Web App ready

## Getting Started

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Start Development Server**
   ```bash
   npm start
   ```

3. **Build for Production**
   ```bash
   npm run build
   ```

## Environment Variables

Create a `.env` file in the client directory:

```env
REACT_APP_API_URL=http://localhost:5000
```

## API Integration

The frontend integrates with a REST API for:
- User authentication
- Item management
- Search functionality
- Chat system
- File uploads
- Real-time updates

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Contributing

1. Follow the existing code style
2. Use meaningful component and variable names
3. Add proper error handling
4. Include loading states
5. Test on multiple devices
6. Update documentation as needed

## License

This project is part of the Lost & Found Community platform.
